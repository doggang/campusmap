            var a = document.getElementById(this);
            function popup(){
                window.open('test.html', '_blank', 'width=800, height=600'); return false;
            }